<h1>Galeri</h1>
<form action="index.php?page=upload" method="POST" enctype="multipart/form-data">
    <label for="">Upload Gambar</label>
    <input type="file" name="gambar">
    <button type="submit">Upload</button>
</form>