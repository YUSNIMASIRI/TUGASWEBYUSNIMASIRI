<center>
<img src="img/yusmi.jpeg" alt="" width="200" height="200">
<hr>
<h1><b>Yuani Masiri</b></h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit.<br>
    Exercitationem non pariatur aliquid quam nemo, est excepturi. Aliquam ipsa iure et odit repellat quaerat omnis quia labore vel reiciendis, temporibus nihil.<br>
Lorem ipsum dolor, sit amet consectetur adipisicing elit. Corrupti laudantium, pariatur perferendis, eum vero,<br>
minima rerum fugit a illo aliquam distinctio tempora? Totam quisquam reiciendis consectetur quasi ab velit placeat.</p>
<br>
</center>
<p>Hobby :
    <ul>
        <li>I don't have a hobby :) </li>
    </ul>
</p>
<hr>
